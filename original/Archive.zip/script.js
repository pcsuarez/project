
document.addEventListener('DOMContentLoaded', () => {
  let basketCount = 0;
  let totalCoins = 0;

  const userInfo = document.querySelector('.user-info');

  document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
      const productCard = button.closest('.product-card');
      const name = productCard.querySelector('h3').innerText;
      const priceText = productCard.querySelector('p').innerText;

      const price = parseInt(priceText.replace(/\D/g, ''), 10);

      basketCount++;
      totalCoins += price;

      userInfo.textContent = `${totalCoins} PokéCoins | Poké Basket (${basketCount})`;

      console.log(`Added to cart: ${name} - ${price} PokéCoins`);
    });
  });
});

const pokeball = document.querySelector('.pokeball-icon');

pokeball.addEventListener('click', () => {
  pokeball.classList.add('spin');

  setTimeout(() => {
    pokeball.classList.remove('spin');
  }, 3000);
});
